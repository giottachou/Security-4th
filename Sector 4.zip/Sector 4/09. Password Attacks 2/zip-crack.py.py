import zipfile
from sys import argv

def crack(f,d):
    zfile = zipfile.ZipFile(f)        
    dfile=open(d, 'r')
    for line in dfile.readlines():
        line=line.strip('\n')
        try:
            zfile.extractall(pwd=line)
        except RuntimeError:
            pass
        else:
            print "Cracked! with Password %s" % line

def main():
    script,f,d = argv     
    crack(f,d)
        
if __name__=="__main__":
    main()