#!/usr/bin/python
# -*- coding: utf-8 -*-

import crypt
import linecache

##  word = linecache.getline('dictionary.txt', 1)
##  line = linecache.getline('passwd', 34)


def testPass(cryptPass,user):
    dicFile = open ('dictionary.txt','r')
    ctype = cryptPass.split("$")[1]
    if ctype == '6':
        print "[+] Hash type SHA-512 detected ..."
    salt = cryptPass.split("$")[2]
    insalt = "$" + ctype + "$" + salt + "$"
    for word in dicFile.readlines():
        word=word.strip('\n')
        cryptWord = crypt.crypt(word,insalt)
        if (cryptWord == cryptPass):
            print "[+] Found password for the user: " + user + " " + word
            return
    print "[-] Password Not Found.\n"
    return

def main():
    passFile = open ('passwd','r')
    line = linecache.getline('passwd', 34)
    line = line.replace("\n","").split(":")
    user = line[0]
    cryptPass = line[1]
    testPass(cryptPass,user)

##def main():
##    passFile = open ('passwd','r')
##    for line in passFile.readlines():
##        line = line.replace("\n","").split(":")
##        user = line[0]
##        cryptPass = line[1]
##        testPass(cryptPass,user)
 
if __name__=="__main__":
    main()
